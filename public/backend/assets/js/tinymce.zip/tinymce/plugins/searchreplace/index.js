// Exports the "searchreplace" plugin for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/plugins/searchreplace')
//   ES2015:
//     import 'tinymce/plugins/searchreplace'
require('./plugin.js');